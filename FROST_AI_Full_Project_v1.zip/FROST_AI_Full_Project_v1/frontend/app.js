const $=id=>document.getElementById(id);
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
 document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===btn));
 document.querySelectorAll(".panel").forEach(x=>x.classList.toggle("active",x.id===btn.dataset.panel));
}));
function bubble(who,text){const div=document.createElement("div");div.className="bubble "+(who==="You"?"user":"bot");const b=document.createElement("b");b.textContent=who;const p=document.createElement("p");p.textContent=text;div.append(b,p);$("messages").append(div);$("messages").scrollTop=$("messages").scrollHeight}
$("chatForm").addEventListener("submit",async e=>{
 e.preventDefault();const message=$("prompt").value.trim();if(!message)return;
 bubble("You",message);$("prompt").value="";bubble("FROST","सोच रहा हूँ…");
 const pending=$("messages").lastElementChild;
 try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message,language:$("language").value})});const data=await r.json();pending.remove();bubble("FROST",data.reply||data.error||"कोई जवाब नहीं मिला।")}
 catch(err){pending.remove();bubble("FROST","Backend से कनेक्शन नहीं हुआ। कृपया Python server चल रहा है या नहीं जाँचो।")}
});
const examples={
 "Python":'print("Hello, FROST!")',
 "Java":'public class Main {\\n  public static void main(String[] args) {\\n    System.out.println("Hello, FROST!");\\n  }\\n}',
 "C#":'using System;\\nclass Program {\\n  static void Main() { Console.WriteLine("Hello, FROST!"); }\\n}',
 "C++":'#include <iostream>\\nint main() { std::cout << "Hello, FROST!\\\\n"; return 0; }',
 "HTML":'<!doctype html>\\n<html><body><h1>Hello, FROST!</h1></body></html>',
 "JavaScript":'console.log("Hello, FROST!");'
};
$("showExample").onclick=()=>{$("code").value=examples[$("codeLang").value].replaceAll("\\\\n","\\n");$("codeInfo").textContent="Example loaded for "+$("codeLang").value+". This editor does not execute or compile code."};
$("codeLang").onchange=()=>{$("codeInfo").textContent="Selected language: "+$("codeLang").value+". Press Show example to load a sample."};
$("makePlan").onclick=()=>{const f=$("feature").value.trim();if(!f){$("plan").textContent="पहले फीचर का वर्णन लिखो।";return}
$("plan").textContent="Feature request: "+f+"\\n\\nSafe implementation checklist:\\n1. Requirements और acceptance criteria तय करें।\\n2. Source change का छोटा proposal/diff तैयार करें।\\n3. अलग working copy में tests चलाएँ।\\n4. Security और regressions जाँचें।\\n5. Backup बनाकर user approval लें।\\n6. Approval के बाद manually apply करें।\\n\\nयह prototype केवल plan बनाता है; कोई file modify नहीं की गई।"};
