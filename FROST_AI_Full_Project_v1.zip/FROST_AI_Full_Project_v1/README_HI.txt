FROST AI — Full Project Starter v1
==================================
यह A+B+C+D लक्ष्य के लिए शुरुआती multi-language project है।

Quick start:
1. ZIP extract करें।
2. Python 3.10+ वाले environment में backend/server.py चलाएँ।
3. Browser में http://127.0.0.1:8787 खोलें।
4. Chat, Coding Lab, Feature Builder और System tabs देखें।

Android:
- Android tablet पर Python runner में server.py चलाने की कोशिश कर सकते हैं; app को background में रखने पर Android उसे रोक सकता है।
- android/README_JAVA_ANDROID.txt में native Java APK की योजना है।
- इस ZIP में APK शामिल नहीं है; native APK बनाने के लिए Android SDK/Gradle project और वास्तविक device testing चाहिए।

Languages:
- Python: working starter backend
- HTML/CSS/JavaScript: working responsive interface
- Java: Android implementation plan only
- C# and C++: optional extension plans only

यह पूर्ण AI नहीं है। Built-in replies सीमित हैं। Real AI, speech, full offline model, durable memory, secure API integration, and APK are future stages. Existing FROST project को merge करने से पहले backup रखें.
