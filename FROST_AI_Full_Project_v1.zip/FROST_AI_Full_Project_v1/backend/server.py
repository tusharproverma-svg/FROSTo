"""FROST AI starter backend (Python standard library only).

Run:
    python server.py
Then open http://127.0.0.1:8787

This starter is intentionally local-only. It does not pretend to be a trained AI model.
Connect a real model/provider later in a dedicated adapter, keeping API keys server-side.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
import json
import os
import time

HOST = "127.0.0.1"
PORT = int(os.environ.get("FROST_PORT", "8787"))
ROOT = os.path.dirname(os.path.abspath(__file__))
FRONTEND = os.path.abspath(os.path.join(ROOT, "..", "frontend"))

def reply_for(message: str) -> str:
    text = message.strip()
    low = text.lower()
    if not text:
        return "अपना सवाल लिखो। / Please type a question."
    if any(k in low for k in ["hello", "hi", "hey", "नमस्ते", "नमस्कार"]):
        return "नमस्ते! मैं FROST starter हूँ। अभी मैं basic offline replies देता हूँ; असली AI model अभी connect नहीं है।"
    if "python" in low:
        return "Python एक programming language है। FROST के इस starter में backend Python में है। उदाहरण: print('Hello, FROST!')"
    if "javascript" in low or "जावास्क्रिप्ट" in low:
        return "JavaScript इंटरफ़ेस को interactive बनाती है और backend API को call कर सकती है।"
    if "java" in low:
        return "Java Android app module में उपयोगी हो सकती है। इस starter में Android project skeleton अलग दिया गया है।"
    if "c++" in low or "c plus plus" in low:
        return "C++ performance-critical native modules के लिए विकल्प है; पहले interfaces और tests तय करना ज़रूरी है।"
    if "c#" in low or "c sharp" in low:
        return "C# वैकल्पिक desktop/tooling module में उपयोगी हो सकती है; core backend के लिए इसे अभी आवश्यक नहीं बनाया गया।"
    if "html" in low:
        return "HTML पेज का structure बनाती है; CSS appearance और JavaScript interactions संभालते हैं।"
    if any(k in low for k in ["offline", "बिना इंटरनेट"]):
        return "Offline mode अभी केवल सीमित built-in replies देता है। Full offline AI के लिए अलग local model और पर्याप्त device resources चाहिए।"
    if any(k in low for k in ["feature", "upgrade", "फीचर", "अपग्रेड"]):
        return "Safe feature workflow: request → proposal → review → isolated tests → backup → explicit approval → apply. यह starter अभी files को अपने-आप modify नहीं करता।"
    return ("मैं अभी starter mode में हूँ, इसलिए यह जवाब सीमित है। वास्तविक open-ended chat के लिए सुरक्षित तरीके से AI provider/local model adapter जोड़ना होगा. "
            "You can ask about Python, Java, C#, C++, HTML, JavaScript, or FROST architecture.")

class Handler(BaseHTTPRequestHandler):
    def send_json(self, status, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1:%d" % PORT)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1:%d" % PORT)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/health":
            return self.send_json(200, {"ok": True, "name": "FROST", "mode": "starter", "time": int(time.time())})
        if path in ("/", "/index.html"):
            file_path = os.path.join(FRONTEND, "index.html")
            try:
                data = open(file_path, "rb").read()
            except OSError:
                return self.send_json(500, {"error": "frontend/index.html missing"})
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if path in ("/app.js", "/style.css"):
            file_path = os.path.join(FRONTEND, path.lstrip("/"))
            try:
                data = open(file_path, "rb").read()
            except OSError:
                return self.send_error(404)
            ctype = "application/javascript; charset=utf-8" if path.endswith(".js") else "text/css; charset=utf-8"
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        self.send_error(404)

    def do_POST(self):
        if urlparse(self.path).path != "/api/chat":
            return self.send_error(404)
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length > 16_000:
                return self.send_json(413, {"error": "Message too large"})
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            message = str(payload.get("message", ""))[:4000]
            language = str(payload.get("language", "auto"))[:20]
            return self.send_json(200, {
                "reply": reply_for(message),
                "mode": "offline-starter",
                "language": language,
                "note": "Built-in demo response; no online model is connected."
            })
        except (ValueError, json.JSONDecodeError):
            return self.send_json(400, {"error": "Invalid JSON"})

    def log_message(self, fmt, *args):
        print("[FROST]", fmt % args)

if __name__ == "__main__":
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"FROST starter running at http://{HOST}:{PORT}")
    print("Local-only starter. Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
