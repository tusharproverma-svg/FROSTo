Android module plan (Java)
=========================
The full native Android application is NOT yet implemented in this starter.
This directory documents the next build stage:
1. Create an Android Studio project with Java.
2. Add a WebView or native chat screen to host the frontend.
3. Prefer a local backend only for development. For production, use a proper service endpoint and authentication.
4. Do not hardcode API keys in the APK.
5. Test on Android 12 and the user's 4 GB RAM device.
6. Build and test a debug APK before release.

No APK is included because a valid Android SDK/Gradle build environment and signing/test cycle are required.
