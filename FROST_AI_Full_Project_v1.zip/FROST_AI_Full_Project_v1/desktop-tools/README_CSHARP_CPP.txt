Optional native/desktop modules
================================
C# and C++ are planned extension points, not implemented programs in v1.
- C# may host a separate Windows desktop companion/tooling app.
- C++ may be used for performance-critical native libraries via JNI/NDK, only where benchmarks justify it.
Keep interfaces documented and add tests before connecting either module to the Python backend.
